sap.ui.define([
    "sap/ui/core/mvc/Controller",
    'sap/ui/model/Filter', 
    'sap/ui/model/FilterOperator'  // imported json model class
],
    /**
     * @param {typeof sap.ui.core.mvc.Controller} Controller
     */
    function (Controller,  Filter, FilterOperator) {
        "use strict";

        return Controller.extend("com.srinivas.sd.odataexamplenorthwind.controller.S1", {
            onInit: function () {

            },
            handleProductNameSearch: function(oEvent){
                var query = oEvent.getParameter("query");
                // alert(query);
                
                var aFilter = new Filter({
                    path: "ProductName",
                    operator: FilterOperator.Contains,
                    value1: query
                  });
                
                var leaveList = this.getView().byId("productList"); // <List mode="SingleSelectMaster" selectionChange="handleList" items="{localModel>/leaves}" id="leaveList">
                var itemsObj = leaveList.getBinding("items");
                itemsObj.filter([aFilter]);
            }
        });
    });
