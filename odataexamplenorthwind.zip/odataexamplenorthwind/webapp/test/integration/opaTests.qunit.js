/* global QUnit */

sap.ui.require(["com/srinivas/sd/odataexamplenorthwind/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
