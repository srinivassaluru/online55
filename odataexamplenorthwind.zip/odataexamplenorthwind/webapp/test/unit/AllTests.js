sap.ui.define([
	"comsrinivassd/odataexamplenorthwind/test/unit/controller/S1.controller"
], function () {
	"use strict";
});
