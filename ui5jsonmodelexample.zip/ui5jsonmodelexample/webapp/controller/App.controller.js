sap.ui.define(
    [
        "sap/ui/core/mvc/Controller"
    ],
    function(BaseController) {
      "use strict";
  
      return BaseController.extend("com.srinivas.feb9.ui5jsonmodelexample.controller.App", {
        onInit() {
        }
      });
    }
  );
  