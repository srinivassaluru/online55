/* global QUnit */

sap.ui.require(["com/srinivas/feb9/ui5jsonmodelexample/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
