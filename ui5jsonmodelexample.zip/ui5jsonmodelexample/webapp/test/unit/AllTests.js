sap.ui.define([
	"comsrinivasfeb9/ui5jsonmodelexample/test/unit/controller/View1.controller"
], function () {
	"use strict";
});
